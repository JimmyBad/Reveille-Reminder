import csv
import string
#import time
#import pandas
'''
example_array = [{
	"name": "<name>",
	"due": "<due>",
	"course": "<course>",
	"category": "<category>",
	"grade": "<grade>",
	"time" : "<time>"
}]
'''
'''
headers = "{name}, {due_date}, {course}, {category}, {grade}, {time_worked_on}"
'''

def print_test():
	print("This is a test")

def print_greeting():
	'''Function for initial greeting'''
	greeting = "Howdy!!! Welcome to the <insertnamehere> App."
	print(greeting)

def print_menu():
	'''Function for printing options'''
	print("Please select an option from the list below...")
	print("1: My Tasks")
	print("2: My Progress")
	print("3: Calendar")
	print("4: Add Assignment")
	print("5: Print Assignments")
	print("6: Delete Assignment")
	print("7: Add Assignment Grade")
	print("8: Exit")

def print_tasks():
	print("What would you like to do?")
	print("1: Print Assignments")
	print("2: Add Assignment")
	print("3: Delete Assignment")
	print("4: Add Assignment Grade")
	print("Other: Home Menu")

def collect_data():
	filename = "data.csv"

	data = []
	name = ""
	due = ""
	course = ""
	category = ""
	grade = ""
	time = ""
	completion = ""

	with open(filename) as f:
		reader = csv.reader(f)
		header_row = next(reader)

		#for index, column_header in enumerate(header_row):
			#print(index, column_header)
			#print(header_row)

		for row in reader:
			name = row[0]
			due = row[1]
			course = row[2]
			#category = row[3]
			#grade = row[4]
			#time = row[5]
			#completion = row[6]

			data.append({
				"name": name,
				"due": due,
				"course": course,
				#"category": category,
				#"grade": grade,
				#"time" : time,
				#"completion" : completion
				})
		
		return data

def save_data(data):

	filename = "data.csv"

	with open(filename, 'w') as f:
		writer = csv.writer(f)

		header_row = ["name", "due", "course", "category", "grade", "time", "completion"]

		writer.writerow(header_row)

		for i in data:
			'''
			row = [i["name"], i["due"], i["course"],
			 i["category"], i["grade"], i["time"], i["completion"]]
			'''
			row = [i["name"], i["due"], i["course"]]
			writer.writerow(row)



def print_data(data):
	'''A function for outputting collected data'''

	text = ""

	for i in data:
		name = i["name"]
		due = i["due"]
		course = i["course"]
		#category = i["category"]
		#grade = i["grade"]
		#time = i["time"]
		#completion = i["completion"]

		print(f"{course}, {name}, {due}")
		#text = f"{name}, {due}, {course}, {category}, {grade}, {time}, {completion}"
		text = f"{name}, {due}, {course}"


'''
def add_assignment(data):
	name = input("Name: ")
	due = input("Due Date: ")
	course = input("Course: ")
	category = input("Category: ")
	grade = input("Grade: ")
	grade = 0
	time = 0
	completion = 0

	data.append({
		"name": name,
		"due": due,
		"course": course,
		"category": category,
		"grade": grade,
		"time": time,
		"completion": completion
		})

'''
def add_assignment(data, course, name, due):

	grade = 0
	time = 0
	completion = 0

	data.append({
		"name": name,
		"due": due,
		"course": course,
		#"category": category,
		#"grade": grade,
		#"time": time,
		#"completion": completion
		})


def remove_assignment(data):
	course = input("Which course is this assignment from?: ")
	name = input("Which assignment would you like to remove: ")

	for index, i in enumerate(data):
		if i["name"] == name and i["course"] == course:
			data.pop(index)
			break

'''
def publish_data(data):
	filename = "data.csv"

	with open(filename, w) as f:
'''

def change_grade(data):

	name = input("Which assignment would you like to grade? ")
	course = input("Which course is this assignment from? ")
	grade = input("What grade did you get? ")

	for index, i in enumerate(data):
		if i["name"] == name and i["course"] == course:
			i["grade"] = grade
			break

#def sort_by_class():


#def sort_by_date():

'''
def print_phone():
	print(" _____________________________________________________")
	for i in range(0, 55):
		print("|                                                     |")
	print(" _____________________________________________________")
'''
